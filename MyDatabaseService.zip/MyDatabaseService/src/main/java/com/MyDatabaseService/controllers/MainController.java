package com.MyDatabaseService.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.MyDatabaseService.entity.Employee;
import com.MyDatabaseService.repo.EmpServiceImpl;

@Controller
public class MainController {
	@Autowired
	EmpServiceImpl er;
	
	@GetMapping("/")
	public String WelcomePage()
	{
		return "Welcome";
	}
	
	@PostMapping("login")
	public String loginProcess(@RequestParam String username,@RequestParam String password,Model m)
	{
		if(username.equals("mydb")&&password.equals("123456"))
		{
			return "Homepage";
		}
		else
			m.addAttribute("msg","Wrong username/password");
		return "Welcome";
	}
	
	@GetMapping("addNew")
	public String AddNewEmployee(Model m)
	{
		return "AddNew";
	}
	
	@GetMapping("search")
	public String SearchEmployee(Model m)
	{
		return "Search";
	}
	
	@GetMapping("showAll")
	public String ShowAllEmployee(Model m)
	{
		List<Employee> elist=er.showAll();
		if(elist!=null)
		{
			m.addAttribute("list", elist);
		}
		else
		{
			m.addAttribute("msg","Can't display!");
		}
		return "Display";
	}
	
	@GetMapping("removeEmp")
	public String RemoveEmployee(Model m)
	{
		return "Delete";
	}
	
	@PostMapping("addnewprocess")
	public String AddProcess(@RequestParam String id,@RequestParam String name,@RequestParam String job,
			@RequestParam String loc,Model m)
	{
		Employee e=new Employee();
		e.setId(Integer.parseInt(id));
		e.setName(name);
		e.setJobProfile(job);
		e.setLocation(loc);
		String r=er.addEmp(e);
		m.addAttribute("msg",r);
		return "AddNew";
	}
	
	@PostMapping("delprocess")
	public String DeleteProcess(@RequestParam String id,Model m)
	{
		String r=er.delEmp(Integer.parseInt(id));
		m.addAttribute("msg", r);
		return "Delete";
	}
	
	@PostMapping("searchprocess")
	public String SearchProcess(@RequestParam String id,Model m)
	{
		Employee e=er.searchEmp(Integer.parseInt(id));
		if(e==null)
		{
			m.addAttribute("msg","Employee not found");
		}
		else
		{
			m.addAttribute("emp", e);
		}
		return "Search";
	}

}
