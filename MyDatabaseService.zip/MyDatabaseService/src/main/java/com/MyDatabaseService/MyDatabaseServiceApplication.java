package com.MyDatabaseService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyDatabaseServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyDatabaseServiceApplication.class, args);
		System.out.println("Service started...");
	}

}
