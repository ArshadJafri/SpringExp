package com.MyDatabaseService.repo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.MyDatabaseService.entity.Employee;

@Component
public class EmpServiceImpl implements EmpService {
	@Autowired
	JdbcTemplate jt;

	@Override
	public String addEmp(Employee e) {
		String str="insert into emplist(id,name,job_profile,location)"
				+ " values(?,?,?,?);";
		try
		{
			int r=jt.update(str,new Object[] {e.getId(),e.getName(),e.getJobProfile(),e.getLocation()});
			if(r>=1)
				return "Employee added...";
		}
		catch(Exception ex)
		{
			return "Can't add employee!";
		}
		return "Can't add employee!";
	}

	@Override
	public Employee searchEmp(int id) {
		String str="select * from emplist where id=?;";
		Employee emp=null;
		try
		{
			emp=(Employee) jt.queryForObject(str,new Object[] {id},new BeanPropertyRowMapper(Employee.class));
			return emp;
		}
		catch(Exception e)
		{
			return null;
		}
	}

	@Override
	public List<Employee> showAll() {
		List<Employee> reslist=new ArrayList<>();
		String str="select * from emplist;";
		try
		{
			reslist=jt.query(str, new BeanPropertyRowMapper(Employee.class));
			return reslist;
		}
		catch(Exception e)
		{
			return null;
		}
	}

	@Override
	public String delEmp(int id) {
		String str="delete from emplist where id=?;";
		int res=jt.update(str, new Object[] {id});
		if(res>=1)
			return "Deletion successful!";
		else
			return "Employee not found!";
	}

}
