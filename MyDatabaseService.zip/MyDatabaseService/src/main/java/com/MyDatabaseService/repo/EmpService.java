package com.MyDatabaseService.repo;

import java.util.List;

import com.MyDatabaseService.entity.Employee;

public interface EmpService {
	public String addEmp(Employee e);
	public Employee searchEmp(int id);
	public List<Employee> showAll();
	public String delEmp(int id);

}
