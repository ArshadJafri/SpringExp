package com.MyDatabaseService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyDatabaseServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
